This is an assignment.
The app shows an example for pagination.
The data is stored in src/data/data.js

first install node modules by running "yarn install"
to start the development server: run the command "npm start" or "yarn start"
