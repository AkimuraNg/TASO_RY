import React from "react";
import { useParams } from "react-router-dom";
import BlogCard from "../BlogCard/BlogCard";
import blogData from "../../data/data";

const Blog = () => {
  const { pageNumber } = useParams();
  const numberOfBlogsPerPage = 8;
  const start = (parseInt(pageNumber) - 1) * parseInt(numberOfBlogsPerPage);
  const blogsForThisPage = blogData.slice(start, start + numberOfBlogsPerPage);
  const numberOfPages = parseInt(blogData.length / numberOfBlogsPerPage) + 1;
  const pages = Array.apply(null, { length: numberOfPages }).map(
    Number.call,
    Number
  );
  let previous = pageNumber - 1;
  if (previous === 0) {
    previous = 1;
  }
  let next = parseInt(pageNumber) + 1;
  if (next > pages.length) {
    next = pages.length;
  }
  return (
    <div className="gimme-space">
      <h1>BLOGS & NEW</h1>
      <div className="container d-flex flex-wrap">
        {blogsForThisPage.map((blog) => (
          <BlogCard key={blog.title} blog={blog} />
        ))}
      </div>
      <div className="d-flex justify-content-center">
        <nav aria-label="Page navigation example">
          <ul className="pagination">
            <li className="page-item">
              <a className="page-link" href={`/blogs/${previous}`}>
                Previous
              </a>
            </li>

            {pages.map((page) => (
              <li className="page-item" key={page}>
                <a className="page-link" href={`/blogs/${page + 1}`}>
                  {page + 1}
                </a>
              </li>
            ))}

            <li className="page-item">
              <a className="page-link" href={`/blogs/${next}`}>
                Next
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </div>
  );
};

export default Blog;
