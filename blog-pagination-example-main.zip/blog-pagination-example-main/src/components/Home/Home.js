import React from "react";

const Home = () => {
  return (
    <div className="gimme-space">
      <a href="/blogs/1" className="btn btn-primary">
        Go to blogs
      </a>
    </div>
  );
};

export default Home;
