import React from "react";

const NotFound = () => {
  return (
    <div>
      <p>
        oh! something went wrong. Go back to <a href="/">home</a>?
      </p>
    </div>
  );
};

export default NotFound;
