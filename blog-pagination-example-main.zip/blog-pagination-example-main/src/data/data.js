const blogData = [
  {
    title: "Blog 1",
    detail:
      "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis unde nisi sint perferendis blanditiis magnam molestias quasi consequatur consequuntur minus, vitae sunt numquam id explicabo similique illo nobis voluptatem quibusdam!",
  },
  {
    title: "Blog 2",
    detail:
      "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis unde nisi sint perferendis blanditiis magnam molestias quasi consequatur consequuntur minus, vitae sunt numquam id explicabo similique illo nobis voluptatem quibusdam!",
  },
  {
    title: "Blog 3",
    detail:
      "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis unde nisi sint perferendis blanditiis magnam molestias quasi consequatur consequuntur minus, vitae sunt numquam id explicabo similique illo nobis voluptatem quibusdam!",
  },
  {
    title: "Blog 4",
    detail:
      "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis unde nisi sint perferendis blanditiis magnam molestias quasi consequatur consequuntur minus, vitae sunt numquam id explicabo similique illo nobis voluptatem quibusdam!",
  },
  {
    title: "Blog 5",
    detail:
      "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis unde nisi sint perferendis blanditiis magnam molestias quasi consequatur consequuntur minus, vitae sunt numquam id explicabo similique illo nobis voluptatem quibusdam!",
  },
  {
    title: "Blog 6",
    detail:
      "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis unde nisi sint perferendis blanditiis magnam molestias quasi consequatur consequuntur minus, vitae sunt numquam id explicabo similique illo nobis voluptatem quibusdam!",
  },
  {
    title: "Blog 7",
    detail:
      "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis unde nisi sint perferendis blanditiis magnam molestias quasi consequatur consequuntur minus, vitae sunt numquam id explicabo similique illo nobis voluptatem quibusdam!",
  },
  {
    title: "Blog 8",
    detail:
      "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis unde nisi sint perferendis blanditiis magnam molestias quasi consequatur consequuntur minus, vitae sunt numquam id explicabo similique illo nobis voluptatem quibusdam!",
  },
  {
    title: "Blog 9",
    detail:
      "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis unde nisi sint perferendis blanditiis magnam molestias quasi consequatur consequuntur minus, vitae sunt numquam id explicabo similique illo nobis voluptatem quibusdam!",
  },
  {
    title: "Blog 10",
    detail:
      "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis unde nisi sint perferendis blanditiis magnam molestias quasi consequatur consequuntur minus, vitae sunt numquam id explicabo similique illo nobis voluptatem quibusdam!",
  },
  {
    title: "Blog 11",
    detail:
      "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis unde nisi sint perferendis blanditiis magnam molestias quasi consequatur consequuntur minus, vitae sunt numquam id explicabo similique illo nobis voluptatem quibusdam!",
  },
  {
    title: "Blog 12",
    detail:
      "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis unde nisi sint perferendis blanditiis magnam molestias quasi consequatur consequuntur minus, vitae sunt numquam id explicabo similique illo nobis voluptatem quibusdam!",
  },
  {
    title: "Blog 13",
    detail:
      "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis unde nisi sint perferendis blanditiis magnam molestias quasi consequatur consequuntur minus, vitae sunt numquam id explicabo similique illo nobis voluptatem quibusdam!",
  },
  {
    title: "Blog 14",
    detail:
      "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis unde nisi sint perferendis blanditiis magnam molestias quasi consequatur consequuntur minus, vitae sunt numquam id explicabo similique illo nobis voluptatem quibusdam!",
  },
  {
    title: "Blog 15",
    detail:
      "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis unde nisi sint perferendis blanditiis magnam molestias quasi consequatur consequuntur minus, vitae sunt numquam id explicabo similique illo nobis voluptatem quibusdam!",
  },
  {
    title: "Blog 16",
    detail:
      "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis unde nisi sint perferendis blanditiis magnam molestias quasi consequatur consequuntur minus, vitae sunt numquam id explicabo similique illo nobis voluptatem quibusdam!",
  },
  {
    title: "Blog 17",
    detail:
      "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis unde nisi sint perferendis blanditiis magnam molestias quasi consequatur consequuntur minus, vitae sunt numquam id explicabo similique illo nobis voluptatem quibusdam!",
  },
  {
    title: "Blog 18",
    detail:
      "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis unde nisi sint perferendis blanditiis magnam molestias quasi consequatur consequuntur minus, vitae sunt numquam id explicabo similique illo nobis voluptatem quibusdam!",
  },
  {
    title: "Blog 19",
    detail:
      "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis unde nisi sint perferendis blanditiis magnam molestias quasi consequatur consequuntur minus, vitae sunt numquam id explicabo similique illo nobis voluptatem quibusdam!",
  },
  {
    title: "Blog 20",
    detail:
      "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis unde nisi sint perferendis blanditiis magnam molestias quasi consequatur consequuntur minus, vitae sunt numquam id explicabo similique illo nobis voluptatem quibusdam!",
  },
];

export default blogData;
